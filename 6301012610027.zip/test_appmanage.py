import unittest
from appmanage import manager
import pandas

class TestAppmanage(unittest.TestCase):

    def setUp(self):
        self.manager = manager()
        self.manager.load_file('Superstore.csv')

    def test_get_header(self):
        self.assertIsInstance(self.manager.get_header(), list)
    
    def test_get_data(self):
        self.assertIsInstance(self.manager.get_data(), pandas.core.frame.DataFrame)

if __name__ == "__main__":
    unittest.main()
    